package org.example.Views.InGameMenus;

import org.example.Models.Shops.Shop;
import org.example.Views.AppMenu;

import java.util.Scanner;

public class ShopMenu implements AppMenu {
    private static Shop shop;

    @Override
    public void handleInput(Scanner sc) {

    }
    // items ...

}
