package org.example.Views.InGameMenus;

import org.example.Views.AppMenu;

import java.util.Scanner;

public class InventoryMenu implements AppMenu {
    @Override
    public void handleInput(Scanner sc) {

    }
}
