package org.example.Enums.GameConsts;


/*
    Some items have prices.
 */
public enum SellPrices {
    //Quartz(60);
    // ...
}
