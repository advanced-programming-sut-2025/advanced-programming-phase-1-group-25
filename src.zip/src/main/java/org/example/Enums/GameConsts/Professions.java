package org.example.Enums.GameConsts;

/*
    Some NPCs have jobs.
 */
public enum Professions {

}
