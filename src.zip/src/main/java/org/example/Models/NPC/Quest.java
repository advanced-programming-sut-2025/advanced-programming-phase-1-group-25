package org.example.Models.NPC;

/*
    In a relation, we can have quests to do.
 */
public class Quest {

    private String description;
    private boolean state; // in done, active or ...

}
