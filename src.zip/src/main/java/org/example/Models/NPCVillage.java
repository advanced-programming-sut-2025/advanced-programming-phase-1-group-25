package org.example.Models;

import org.example.Models.MapElements.Tile;

public class NPCVillage {
    Tile[][] area;
}
