package org.example.Models.Player;


/*
    Each player has 4 different abilities with their levels. We store all abilities for each player in a class;
 */
public class PlayerAbilities {
    private int farmingAbility;
    private int miningAbility;
    private int natureAbility;
    private int fishingAbility;
}
