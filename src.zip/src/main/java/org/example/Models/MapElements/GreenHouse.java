package org.example.Models.MapElements;

public class GreenHouse {
    private Tile[][] area;
    private boolean isRepaired;

}
