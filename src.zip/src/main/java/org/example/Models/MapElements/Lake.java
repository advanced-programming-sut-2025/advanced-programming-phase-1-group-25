package org.example.Models.MapElements;


public class Lake {
    private Tile[] area;

}
