package org.example.Models.MapElements;

public class Quarry {
    private Tile[] area;
}
