package org.example.Models.MapElements;


public class Cottage {
    private Tile[] area;

}
