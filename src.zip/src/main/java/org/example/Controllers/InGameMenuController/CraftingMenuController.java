package org.example.Controllers.InGameMenuController;

public class CraftingMenuController {
    public static void craft() {

    }
}
