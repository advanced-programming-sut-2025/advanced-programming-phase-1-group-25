package org.example.Controllers.InGameMenuController;

public class InventoryController {
    public static void select() {

    }
}
