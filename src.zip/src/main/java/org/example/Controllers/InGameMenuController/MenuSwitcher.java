package org.example.Controllers.InGameMenuController;

public class MenuSwitcher {
    public static void switchMenu(String menu) {
//        switch (menu) {
//            case:
//                break;
//            case:
//                break;
//        }
    }
}
