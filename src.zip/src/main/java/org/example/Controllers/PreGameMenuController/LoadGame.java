package org.example.Controllers.PreGameMenuController;

public class LoadGame {
    // make map
    //return farms
}
