package org.example.Controllers.UpdateMap;

/*
    Logins to update the foraging items of the map every morning.
 */
public class UpdateForaging {
    public static void spawnForagingMinerals() {

    }
    public static void spawnForagingCrops() {

    }
    public static void spawnForagingSeeds() {

    }
}
