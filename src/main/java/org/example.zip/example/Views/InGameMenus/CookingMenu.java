package org.example.Views.InGameMenus;

import org.example.Views.AppMenu;

import java.util.Scanner;

public class CookingMenu implements AppMenu {
    @Override
    public void handleInput(Scanner sc) {

    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public String prompt(String message) {
        return "";
    }
}
