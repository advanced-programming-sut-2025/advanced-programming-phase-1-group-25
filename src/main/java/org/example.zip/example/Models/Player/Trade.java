package org.example.Models.Player;

import org.example.Models.Item.ItemDefinition;

public class Trade {
}
