package org.example.Models.MapElements;

public class Farm {
    private Tile[] area;
    private Lake[] lakes;
    private GreenHouse greenHouse;
    private Quarry[] quarries;
    private Cottage cottage;
}