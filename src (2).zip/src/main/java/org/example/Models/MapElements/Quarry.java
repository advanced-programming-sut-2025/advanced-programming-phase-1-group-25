package org.example.Models.MapElements;

public class Quarry {
    private Tile tile;
    public Quarry(Tile tile) {
        this.tile = tile;
    }
}
