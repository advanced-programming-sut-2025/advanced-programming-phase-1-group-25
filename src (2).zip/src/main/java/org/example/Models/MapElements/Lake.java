package org.example.Models.MapElements;


public class Lake {
    private Tile tile;
    public Lake(Tile tile) {
        this.tile = tile;
    }

}
