package org.example.Models.MapElements;

public class House {
    private Tile[] area;
}
