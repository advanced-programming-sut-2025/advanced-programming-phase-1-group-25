package org.example.Enums.GameConsts;

public enum Gender {
    MALE,
    FEMALE,
    OTHER;
}
