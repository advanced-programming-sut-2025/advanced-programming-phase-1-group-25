package org.example.Enums.GameConsts;

/*
    We have all dialogs possible in the game here!
 */
public enum Dialogs {
    //    ThanksForGift_5("message...");
    // ...
}
