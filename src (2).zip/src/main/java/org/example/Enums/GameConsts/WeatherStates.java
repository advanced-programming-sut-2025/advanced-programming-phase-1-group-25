package org.example.Enums.GameConsts;

/*
    We have only 4 possible weather states:
 */
public enum WeatherStates {
    SUNNY,
    RAIN,
    STORM,
    SNOW;
}
