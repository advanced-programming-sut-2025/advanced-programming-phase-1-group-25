package org.example.Enums.PreGameMenuCommands;

public enum AvatarMenuCommands {
}
