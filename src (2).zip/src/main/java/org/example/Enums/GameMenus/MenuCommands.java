package org.example.Enums.GameMenus;

import java.util.regex.Matcher;

public interface MenuCommands {
    Matcher getMatcher(String input);
}
