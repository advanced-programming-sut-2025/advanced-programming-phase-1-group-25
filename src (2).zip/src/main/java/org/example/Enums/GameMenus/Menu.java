package org.example.Enums.GameMenus;

import java.util.Scanner;

/*
    Interface for all menu enums.
 */
public interface Menu {
    void check(Scanner sc);
}
