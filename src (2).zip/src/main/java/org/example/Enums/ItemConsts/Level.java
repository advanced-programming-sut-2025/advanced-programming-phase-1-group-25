package org.example.Enums.ItemConsts;

public interface Level {
}
