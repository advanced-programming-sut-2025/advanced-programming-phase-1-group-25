package org.example.Enums.ItemConsts;

public enum ItemAttributes {
    damage, durability, energyCost,
    upgradeCost, percentage,
    source,
    stages,
    totalHarvestTime,
    oneTime,
    regrowthTime,
    baseSellPrice,
    isEdible,
    energy,
    season,
    canBecomeGiant,
    description,
    price,
    ingredients,
    capacity,
    products,
    fruitHarvestCycle,
    fruitBaseSellPrice,
    isFruitEdible,
    fruitEnergy,
    fruit;


}
