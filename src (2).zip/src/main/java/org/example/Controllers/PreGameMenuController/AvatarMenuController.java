package org.example.Controllers.PreGameMenuController;

public class AvatarMenuController {
    public static void select() {

    }
}
