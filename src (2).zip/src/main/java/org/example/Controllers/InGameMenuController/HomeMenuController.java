package org.example.Controllers.InGameMenuController;

public class HomeMenuController {
    public static void home() {

    }
}
