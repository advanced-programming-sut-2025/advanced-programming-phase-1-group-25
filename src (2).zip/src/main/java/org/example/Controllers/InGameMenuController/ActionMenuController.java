package org.example.Controllers.InGameMenuController;

import com.fasterxml.jackson.databind.AnnotationIntrospector;
import org.example.Enums.GameMenus.Menus;
import org.example.Enums.ItemConsts.ItemDisplay;
import org.example.Enums.ItemConsts.ItemAttributes;
import org.example.Enums.ItemConsts.ItemType;
import org.example.Models.App;
import org.example.Models.Game;
import org.example.Models.Item.Inventory;
import org.example.Models.Item.ItemDefinition;
import org.example.Models.Item.ItemInstance;
import org.example.Models.MapElements.GameMap;
import org.example.Models.MapElements.Position;
import org.example.Models.MapElements.Tile;
import org.example.Models.Player.Player;
import org.example.Views.InGameMenus.ActionMenuView;
import org.example.Views.PreGameMenus.TerminalAnimation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;

public class ActionMenuController {
    ActionMenuView view;
    public ActionMenuController(ActionMenuView view) {
        this.view = view;
    }

    public void walk(String yString, String xString) {
        int y, x;
        try {
            y = Integer.parseInt(yString);
            x = Integer.parseInt(xString);
        } catch (NumberFormatException e) {
            this.view.showMessage("Please Enter valid Y and X");
            return;
        }

        // check whether the player can go to the destination or not

        Game currentGame = App.getCurrentGame();
        Player currentPlayer = currentGame.getCurrentPlayer();
        GameMap map = currentGame.getGameMap();
        int currentPlayerY = currentPlayer.getPosition().getY();
        int currentPlayerX = currentPlayer.getPosition().getX();
        Tile start = map.getTile(currentPlayerY, currentPlayerX);
        Tile goal = map.getTile(y, x);

        List<Tile> path = Walk.findPath(start, goal, map);
        if (path == null) {
            this.view.showMessage("No path found.");
            return;
        }

        int energyCost = Walk.calculateWalkEnergyCost(path);

        String input = this.view.prompt(String.format("The best path's energy cost is %d. (Your current energy: %d)\nDo you want to go to the destination?\n" +
                "1. Yes\n" +
                "2. No\n" +
                "3. Walk until my energy runs out.", energyCost, currentPlayer.getEnergy()));
        int number;

        try {
            number = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            this.view.showMessage("Please enter a valid number");
            return;
        }

        int playerEnergy = currentPlayer.getEnergy();

        if (number == 1) {
            if (playerEnergy < energyCost) {
                this.view.showMessage("You don't have enough energy.");
            } else {
                try {
                    TerminalAnimation.loadingAnimation("Walking");
                } catch (InterruptedException e) {
                    this.view.showMessage("Problem walking to the destination. Please try again.");
                    return;
                }
                Walk.walkToDestination(energyCost, y, x);
                this.view.showMessage("You are now in destination!");
            }
        } else if (number == 2) {
            this.view.showMessage("Cancelled.");
        } else if (number == 3) {
            Position finalPosition = Walk.walkUntilEnergyRunsOut(path);
            this.view.showMessage(String.format("You final position is y = %d | x = %d", finalPosition.getY(), finalPosition.getX()));
        } else {
            this.view.showMessage("Invalid command");
        }
    }

    public String nextTurn() {
        Game currentGame = App.getCurrentGame();
        Player nextPlayer = currentGame.getNextPlayer();
        currentGame.setCurrentPlayer(nextPlayer);

        return String.format("%s's turn!\n", nextPlayer.getName());
    }

    public String buildGreenhouse() {
        Game currentGame = App.getCurrentGame();
        Player currentPlayer = currentGame.getCurrentPlayer();
        Inventory playerInventory = currentPlayer.getInventory();

        int playerWood = playerInventory.getItemAmount("wood");
        int playerCoin = currentPlayer.getCoin();

        if (playerWood < 500) {
            return "You don't have enough wood.\n";
        } else if (playerCoin < 1000) {
            return "You don't have enough coin.\n";
        } else {
            currentGame.getPlayerMap(currentPlayer).getGreenHouse().repair();
            currentPlayer.setCoin(currentPlayer.getCoin() - 1000);
            currentPlayer.getInventory().dropItem("wood", 500);
        }
        return "Green house has been repaired.";
    }

    public String cheatAdvanceTime(Matcher matcher, Game game) {
        String timeStr = matcher.group("hours");
        int time;
        try {
            time = Integer.parseInt(timeStr);
        } catch (NumberFormatException e) {
            return "please enter a valid hour!\n";
        }
        if (time < 0) {
            return "time must be a positive number!\n";
        }
        game.getDateTime().updateTimeByHour(time);
        return "";
    }

    public String cheatAdvanceDate(Matcher matcher, Game game) {
        String timeStr = matcher.group("day");
        int time;
        try {
            time = Integer.parseInt(timeStr);
        } catch (NumberFormatException e) {
            return "please enter a valid day!\n";
        }
        if (time < 0) {
            return "time must be a positive number!\n";
        }
        game.getDateTime().updateTimeByDay(time);
        return "";
    }

    //    public String cheatWeather(Matcher matcher, Game game) {
//        String weather = matcher.group("type");
//    }
    public String printMap(String xStr, String yStr, String sizeStr) {
        Game game = App.getCurrentGame();
        int x, y, size;
        try {
            x = Integer.parseInt(xStr);
            y = Integer.parseInt(yStr);
        } catch (NumberFormatException e) {
            return "please enter a valid position!\n";
        }
        try {
            size = Integer.parseInt(sizeStr);
        } catch (NumberFormatException e) {
            return "please enter a valid size!\n";
        }
        Position position = new Position(y, x);
        return getMapBySize(game, position, size);
    }

    public String getMapBySize(Game game, Position position, int size) {
        GameMap map = game.getGameMap();
        String[][] mapArray = new String[2 * size][2 * size];
        for (int i = position.getY() - size; i < position.getY() + size; i++) {
            for (int j = position.getX() - size; j < position.getX() + size; j++) {
                try {
                    ItemType type = map.getTile(i, j).getItem().getDefinition().getType();
                    String symbol = ItemDisplay.getDisplayByType(type);
                    mapArray[i - position.getY() + size][j - position.getX() + size] = symbol;
                } catch (ArrayIndexOutOfBoundsException e) {
                    continue;
                }
            }
        }

        ArrayList<Player> players = App.getCurrentGame().getPlayers();
        int playerNumber = 1;
        for (Player player : players) {
            int playerY = player.getPosition().getY();
            int playerX = player.getPosition().getX();

            if (playerY >= position.getY() - size && playerY < position.getY() + size) {
                if (playerX >= position.getX() - size && playerX < position.getX() + size) {
                    mapArray[playerY - position.getY() + size][playerX - position.getX() + size] = Integer.toString(playerNumber);
                }
            }
            playerNumber++;
        }

        StringBuilder output = new StringBuilder();
        for (int i = 0; i < 2 * size; i++) {
            for (int j = 0; j < 2 * size; j++) {
                output.append(mapArray[i][j]).append(" ");
            }
            output.append("\n");
        }
        return output.toString();
    }

    public String cheatSetEnergy(Matcher matcher, Game game) {
        String energyStr = matcher.group("value");
        int energy;
        try {
            energy = Integer.parseInt(energyStr);
        } catch (NumberFormatException e) {
            return "please enter a valid energy amount!\n";
        }
        game.getCurrentPlayer().setEnergy(energy);
        return "your energy has been set to " + energy + "!\n";
    }

    public String energyUnlimited(Game game) {
        game.getCurrentPlayer().setEnergy(Integer.MAX_VALUE);
        return "your energy is now unlimited:)\n";
    }

    public void changeMenu() {
        App.setCurrentMenu(Menus.InGameMenus.MENU_SWITCHER);
    }

    public String equipTool(Matcher matcher) {
        Game game = App.getCurrentGame();
        String toolName = matcher.group("toolName").toLowerCase();
        Inventory inventory = game.getCurrentPlayer().getInventory();
        boolean found = false;
        for (ItemDefinition itemDefinition : App.getItemDefinitions()) {
            if (itemDefinition.getDisplayName().equalsIgnoreCase(toolName)) {
                found = true;
            }
        }
        if (!found) {
            return "please enter a valid tool name!\n";
        }
        found = false;
        ItemInstance tool = null;
        for (Map.Entry<ItemInstance, Integer> entry : inventory.getItems().entrySet()) {
            ItemInstance item = entry.getKey();
            if (item.getDefinition().getDisplayName().equalsIgnoreCase(toolName)) {
                found = true;
                tool = item;
            }
        }
        if (!found) {
            return "you don't have " + toolName + " in your inventory!\n";
        }
        game.getCurrentPlayer().setCurrentTool(tool);
        return "your current tool has been set to " + toolName + "!\n";
    }

    public String showCurrentTool() {
        Game game = App.getCurrentGame();
        Player currentPlayer = game.getCurrentPlayer();
        if (currentPlayer.getCurrentTool() == null) {
            return "you don't have a current tool!\n";
        }
        return currentPlayer.getCurrentTool().getDefinition().getDisplayName().toLowerCase();
    }

    public String showInventoryTools() {
        Game game = App.getCurrentGame();
        Inventory inventory = game.getCurrentPlayer().getInventory();
        StringBuilder toolsStr = new StringBuilder();
        for (Map.Entry<ItemInstance, Integer> entry : inventory.getItems().entrySet()) {
            ItemInstance item = entry.getKey();
            if (item.getDefinition().getType().equals(ItemType.tool)) {
                toolsStr.append(item.getDefinition().getDisplayName().toLowerCase()).append("\n");
            }
        }
        return toolsStr.toString();
    }

    public String craftInfo(Matcher matcher) {
        String name = matcher.group("craftName");
        ItemDefinition itemDefinition = null;
        for (ItemDefinition tmp : App.getItemDefinitions()) {
            if (tmp.getDisplayName().equalsIgnoreCase(name) && tmp.getType().equals(ItemType.all_crops)) {
                itemDefinition = tmp;
            }
        }
        if (itemDefinition == null) {
            return "please select a crop!\n";
        }
        StringBuilder info = new StringBuilder();
        info.append("Name: ").append(itemDefinition.getDisplayName().toLowerCase()).append("\n");
        for (Map.Entry<ItemAttributes, Object> entry : itemDefinition.getBaseAttributes().entrySet()) {
            ItemAttributes itemAttributes = entry.getKey();
            Object object = entry.getValue();
            info.append(itemAttributes.toString()).append(": ").append(object.toString()).append("\n");
        }
        return info.toString();
    }

    public String useTool(Matcher matcher) {
        String direction = matcher.group("direction").trim();
        Game game = App.getCurrentGame();
        Player player = game.getCurrentPlayer();
        Tile tile = player.getPlayerTile(game);
        ItemInstance tool = player.getCurrentTool();
        if (tool == null) return "you don't have a tool in your hand!\n";
        return switch (direction) {
            case "up" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() - 1, tile.getPosition().getX()), player);
            case "down" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() + 1, tile.getPosition().getX()), player);
            case "left" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY(), tile.getPosition().getX() - 1), player);
            case "right" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY(), tile.getPosition().getX() + 1), player);
            case "up left" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() - 1, tile.getPosition().getX() - 1), player);
            case "up right" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() - 1, tile.getPosition().getX() + 1), player);
            case "down left" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() + 1, tile.getPosition().getX() - 1), player);
            case "down right" -> applyTool(tool, game.getGameMap().getTile
                    (tile.getPosition().getY() + 1, tile.getPosition().getX() + 1), player);
            default -> "please select a valid direction!\n";
        };
    }

    public String applyTool(ItemInstance tool, Tile tile, Player player) {
        String name = tool.getDefinition().getDisplayName().toLowerCase();
        if (name.contains("hoe")) {
            if (!checkIfPlayerHasEnoughEnergy(player, tool)) return "you don't have enough energy!\n";
            player.reduceEnergy(player.getAbilities().getFarmingAbility(), tool, player);
            if (tile.getItem().getDefinition().getType().equals(ItemType.lake)) return "you can't use hoe in lake!\n";
            if (!tile.isEmpty()) return "this tile is not empty!\n";
            if (tile.getPlowed()) return "this tile has already been plowed!\n";
            tile.setPlowed(true);
            return "you've successfully plowed the tile!\n";
        } else if (name.contains("pickaxe")) {
            if (!checkIfPlayerHasEnoughEnergy(player, tool)) return "you don't have enough energy!\n";
            player.reduceEnergy(player.getAbilities().getMiningAbility(), tool, player);
            if (tile.getItem().getDefinition().getType().equals(ItemType.lake))
                return "you can't use pickaxe in lake!\n";
            if (tile.isEmpty() && tile.getPlowed()) {
                tile.setPlowed(false);
                return "this tile has been successfully unplowed!\n";
            }
            tile.setItem(new ItemInstance(Objects.requireNonNull(App.getItemDefinition("VOID"))));//TODO
            return "item has been successfully removed from the tile!\n";
        } else if (name.contains("axe")) {
            if (!checkIfPlayerHasEnoughEnergy(player, tool)) return "you don't have enough energy!\n";
            player.reduceEnergy(player.getAbilities().getFishingAbility(), tool, player);
            if (tile.getItem().getDefinition().getType().equals(ItemType.lake)) return "you can't use axe in lake!\n";
            if (tile.isEmpty()) return "this tile is empty!\n";
            if(tile.getItem().getDefinition().getType().equals(ItemType.wood)){//TODO
                player.getInventory().addItem(tile.getItem(), 1);
                tile.setItem(new ItemInstance(Objects.requireNonNull(App.getItemDefinition("VOID"))));
                return "1 wood has been successfully added to the inventory!\n";
            }

        } else if (name.contains("watering can")) {

        } else if (name.contains("fishing pole")) {

        } else if (name.contains("scythe")) {

        } else if (name.contains("milk pale")) {

        } else if (name.contains("shear")) {

        } else if (name.contains("back pack")) {

        } else if (name.contains("trash can")) {

        } else {
            return "please select a valid tool!\n";
        }
        return "";
    }

    public boolean checkIfPlayerHasEnoughEnergy(Player player, ItemInstance tool) {
        if (player.getAbilities().getAbilityLevel(player.getAbilities().getFarmingAbility()) == 4
                && player.getEnergy() < (int) tool.getDefinition().getAttribute(ItemAttributes.energyCost) - 1) {
            return false;
        }
        if (player.getEnergy() < (int) tool.getDefinition().getAttribute(ItemAttributes.energyCost)) {
            return false;
        }
        return true;
    }
}

