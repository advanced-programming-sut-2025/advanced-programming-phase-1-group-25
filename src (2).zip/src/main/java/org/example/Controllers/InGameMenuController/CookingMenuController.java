package org.example.Controllers.InGameMenuController;

public class CookingMenuController {
    public static void cook() {

    }
}
