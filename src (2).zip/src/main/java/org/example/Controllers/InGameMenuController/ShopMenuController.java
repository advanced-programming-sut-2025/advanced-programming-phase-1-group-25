package org.example.Controllers.InGameMenuController;

public abstract class ShopMenuController {
    public static void buy() {

    }
}
