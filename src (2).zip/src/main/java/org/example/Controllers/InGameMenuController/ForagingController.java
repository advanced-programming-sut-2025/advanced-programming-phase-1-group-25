package org.example.Controllers.InGameMenuController;

public class ForagingController {

}
