package org.example.Controllers.UpdateMap;

import org.example.Enums.ItemConsts.ItemType;
import org.example.Models.App;
import org.example.Models.Item.ItemDefinition;

import java.util.ArrayList;
import java.util.List;

/*
    Logins to update the foraging items of the map every morning.
 */
public class UpdateForaging {
    public static void updateForaging() {
        List<ItemDefinition> foragingMinerals = new ArrayList<>();
        List<ItemDefinition> foragingCrops = new ArrayList<>();
        List<ItemDefinition> foragingSeeds = new ArrayList<>();
        for (ItemDefinition itemDefinition : App.getItemDefinitions()) {
            if (itemDefinition.getType() == ItemType.foraging_minerals) {
                foragingMinerals.add(itemDefinition);
            } else if (itemDefinition.getType() == ItemType.foraging_crops) {
                foragingCrops.add(itemDefinition);
            } else if (itemDefinition.getType() == ItemType.foraging_seeds) {
                foragingSeeds.add(itemDefinition);
            }
        }

        spawn
    }
    public spawnRandomForaging(List<ItemDefinition> foragingDefinitions) {

    }
}
