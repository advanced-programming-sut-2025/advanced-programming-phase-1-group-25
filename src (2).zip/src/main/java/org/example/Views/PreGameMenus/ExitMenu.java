package org.example.Views.PreGameMenus;

import org.example.Views.AppMenu;

import java.util.Scanner;

public class ExitMenu implements AppMenu {
    @Override
    public void handleInput(Scanner sc) {

    }
}
